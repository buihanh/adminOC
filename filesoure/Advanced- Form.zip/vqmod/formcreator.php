<?php

        // Add database
        require('../config.php');
        $con = mysql_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD);
        mysql_select_db(DB_DATABASE, $con);
        $SQL = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "formcreator` (
                            `form_id` int(11) NOT NULL AUTO_INCREMENT,
                            `title` varchar(225) COLLATE utf8_unicode_ci DEFAULT NULL,
                            `url` varchar(225) COLLATE utf8_unicode_ci DEFAULT NULL,
                            `email` varchar(225) COLLATE utf8_unicode_ci DEFAULT NULL,
                            `success_msg` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
                            `status` int(11) NOT NULL,
                            `formdata` text NOT NULL,
                            `total_value` float NOT NULL,
                            `form_ip` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
                            `date_added` int(1) NOT NULL,
                            PRIMARY KEY (`form_id`)
                            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=46 ;";
        mysql_query($SQL, $con);
        die('Setup Successful !');
?>