<?php
class ControllerModuleCreator extends Controller {
	public function index() {   
		$this->redirect($this->url->link('frmcreator/creator', 'token=' . $this->session->data['token'], 'SSL'));
	}
}
?>