<?php

class ControllerFrmcreatorCreator extends Controller {

    private $error = array();

    public function index() {
        $this->language->load('frmcreator/creator');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('frmcreator/creator');

        $this->getList();
    }

    public function insert() {

        $this->language->load('frmcreator/creator');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('frmcreator/creator');

        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
            $form_id = $this->model_frmcreator_creator->addForm($_POST);
            if($form_id == -1){
                echo $this->url->link('frmcreator/creator', 'token=' . $this->session->data['token'], 'SSL'); 
                die; 
            }
            $result = $this->model_setting_setting->getSetting('creator');
            $total = 0;
            if(isset($result['creator_module'])) $total = count($result['creator_module']);
            $result['creator_module'][$total][$this->request->post['form_settings'][4][0]] = $this->request->post['form_settings'][4][1];
            $result['creator_module'][$total][$this->request->post['form_settings'][5][0]] = $this->request->post['form_settings'][5][1];
            $result['creator_module'][$total][$this->request->post['form_settings'][6][0]] = $this->request->post['form_settings'][6][1];
            $result['creator_module'][$total][$this->request->post['form_settings'][7][0]] = $this->request->post['form_settings'][7][1];
            $result['creator_module'][$total][$this->request->post['form_settings'][8][0]] = $form_id;
            $this->model_setting_setting->editSetting('creator', $result);       


            echo $this->url->link('frmcreator/creator', 'token=' . $this->session->data['token'], 'SSL'); 
            
            die; 
        }

        $this->getForm();
    }

    public function update() {
        $this->load->model('setting/setting');

        $this->language->load('frmcreator/creator');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('frmcreator/creator');
        
        if (($this->request->server['REQUEST_METHOD'] == 'POST')) { 
            $result = $this->model_setting_setting->getSetting('creator');
            if(!isset($result['creator_module'])) $result['creator_module'] = array();
            $exist = 0;
            foreach($result['creator_module'] as $row){
                if($row['form_id'] == $this->request->post['form_settings'][8][1]) break;
                $exist++;
            }
            
            $result['creator_module'][$exist][$this->request->post['form_settings'][4][0]] = $this->request->post['form_settings'][4][1];
            $result['creator_module'][$exist][$this->request->post['form_settings'][5][0]] = $this->request->post['form_settings'][5][1];
            $result['creator_module'][$exist][$this->request->post['form_settings'][6][0]] = $this->request->post['form_settings'][6][1];
            $result['creator_module'][$exist][$this->request->post['form_settings'][7][0]] = $this->request->post['form_settings'][7][1];
            $result['creator_module'][$exist][$this->request->post['form_settings'][8][0]] = $this->request->post['form_settings'][8][1];
            
            $this->model_setting_setting->editSetting('creator', $result);       
                    
            $this->model_frmcreator_creator->editForm($this->request->get['form_id'], $this->request->post);
            
            echo $this->url->link('frmcreator/creator', 'token=' . $this->session->data['token'], 'SSL'); 
            
            die; 

         }

        $this->getForm();
    }

    public function delete() {
        $this->load->model('setting/setting');
        $this->language->load('frmcreator/creator');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('frmcreator/creator');

        if (isset($this->request->post['selected']) && $this->validateDelete()) {

            foreach ($this->request->post['selected'] as $creator_id) {
                $result = $this->model_setting_setting->getSetting('creator');
                if(!isset($result['creator_module'])) $result['creator_module'] = array();
                $exist = 0;
                foreach($result['creator_module'] as $row){
                    if($row['form_id'] == $creator_id) break;
                    $exist++;
                }
                
                unset($result['creator_module'][$exist]);
                $result['creator_module'] = array_values($result['creator_module']);
                $this->model_setting_setting->editSetting('creator', $result);  
                $this->model_frmcreator_creator->deleteform($creator_id);
            }

            $this->session->data['success'] = $this->language->get('text_success');

            $this->redirect($this->url->link('frmcreator/creator', 'token=' . $this->session->data['token'], 'SSL'));
        }

        $this->getList();
    }

    private function getList() {
        
        $this->data['breadcrumbs'] = array();

        $this->data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => false
        );

        $this->data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('frmcreator/creator', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => ' :: '
        );

        $this->data['insert'] = $this->url->link('frmcreator/creator/insert', 'token=' . $this->session->data['token'], 'SSL');
        $this->data['delete'] = $this->url->link('frmcreator/creator/delete', 'token=' . $this->session->data['token'], 'SSL');

        $this->data['categories'] = array();

        $results = $this->model_frmcreator_creator->getForms(0);

        foreach ($results as $result) {
            $action = array();

            $action[] = array(
                'text' => $this->language->get('text_edit'),
                'href' => $this->url->link('frmcreator/creator/update', 'token=' . $this->session->data['token'] . '&form_id=' . $result['form_id'], 'SSL')
            );

            $this->data['categories'][] = array(
                'form_id' => $result['form_id'],
                'title' => $result['title'],
                'status' => $result['status'],
                'selected' => isset($this->request->post['selected']) && in_array($result['form_id'], $this->request->post['selected']),
                'action' => $action
            );
        }

        $this->data['heading_title'] = $this->language->get('heading_title');

        $this->data['text_no_results'] = $this->language->get('text_no_results');

        $this->data['column_name'] = $this->language->get('column_name');
        $this->data['column_sort_order'] = $this->language->get('column_sort_order');
        $this->data['column_action'] = $this->language->get('column_action');

        $this->data['button_insert'] = $this->language->get('button_insert');
        $this->data['button_delete'] = $this->language->get('button_delete');

        if (isset($this->error['warning'])) {
            $this->data['error_warning'] = $this->error['warning'];
        } else {
            $this->data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $this->data['success'] = $this->session->data['success'];

            unset($this->session->data['success']);
        } else {
            $this->data['success'] = '';
        }

        $this->template = 'frmcreator/creator_list.tpl';
        $this->children = array(
            'common/header',
            'common/footer'
        );

        $this->response->setOutput($this->render());
    }

    private function getForm() {
        $this->load->model('setting/setting');
        $this->load->model('design/layout');
        $this->data['layouts'] = $this->model_design_layout->getLayouts();
        if (isset($this->request->post['form_settings'])) {
            $creator_data['creator_module'][$this->request->post['form_settings'][5][0]] = $this->request->post['form_settings'][5][1];
            $creator_data['creator_module'][$this->request->post['form_settings'][6][0]] = $this->request->post['form_settings'][6][1];
            $creator_data['creator_module'][$this->request->post['form_settings'][7][0]] = $this->request->post['form_settings'][7][1];
            $this->data['module'] = $creator_data['creator_module'];
        } elseif (isset($this->request->get['form_id']) && $this->config->get('creator_module')) { 
            $result = $this->config->get('creator_module');
            $exist = 0;
            foreach($result as $row){
                if($row['form_id'] == $this->request->get['form_id']) break;
                $exist++;
            }
            $this->data['module'] = $result[$exist];
        }  else{
            $this->data['module']['position'] = '';
        }

        $this->data['heading_title'] = $this->language->get('heading_title');

        $this->data['text_none'] = $this->language->get('text_none');
        $this->data['text_default'] = $this->language->get('text_default');
        $this->data['text_image_manager'] = $this->language->get('text_image_manager');
        $this->data['text_browse'] = $this->language->get('text_browse');
        $this->data['text_clear'] = $this->language->get('text_clear');
        $this->data['text_enabled'] = $this->language->get('text_enabled');
        $this->data['text_disabled'] = $this->language->get('text_disabled');
        $this->data['text_percent'] = $this->language->get('text_percent');
        $this->data['text_amount'] = $this->language->get('text_amount');
        $this->data['text_content_top'] = $this->language->get('text_content_top');
        $this->data['text_content_bottom'] = $this->language->get('text_content_bottom');       
        $this->data['text_column_left'] = $this->language->get('text_column_left');
        $this->data['text_column_right'] = $this->language->get('text_column_right');

        $this->data['entry_name'] = $this->language->get('entry_name');
        $this->data['entry_meta_keyword'] = $this->language->get('entry_meta_keyword');
        $this->data['entry_meta_description'] = $this->language->get('entry_meta_description');
        $this->data['entry_description'] = $this->language->get('entry_description');
        $this->data['entry_store'] = $this->language->get('entry_store');
        $this->data['entry_keyword'] = $this->language->get('entry_keyword');
        $this->data['entry_parent'] = $this->language->get('entry_parent');
        $this->data['entry_image'] = $this->language->get('entry_image');
        $this->data['entry_top'] = $this->language->get('entry_top');
        $this->data['entry_column'] = $this->language->get('entry_column');
        $this->data['entry_sort_order'] = $this->language->get('entry_sort_order');
        $this->data['entry_status'] = $this->language->get('entry_status');
        $this->data['entry_layout'] = $this->language->get('entry_layout');

        $this->data['button_save'] = $this->language->get('button_save');
        $this->data['button_cancel'] = $this->language->get('button_cancel');

        $this->data['tab_general'] = $this->language->get('tab_general');
        $this->data['tab_data'] = $this->language->get('tab_data');
        $this->data['tab_design'] = $this->language->get('tab_design');

        if (isset($this->error['warning'])) {
            $this->data['error_warning'] = $this->error['warning'];
        } else {
            $this->data['error_warning'] = '';
        }

        if (isset($this->error['name'])) {
            $this->data['error_name'] = $this->error['name'];
        } else {
            $this->data['error_name'] = array();
        }

        $this->data['breadcrumbs'] = array();

        $this->data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => false
        );

        $this->data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('frmcreator/creator', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => ' :: '
        );

        if (!isset($this->request->get['creator_id'])) {
            $this->data['action'] = $this->url->link('frmcreator/creator/insert', 'token=' . $this->session->data['token'], 'SSL');
        } else {
            $this->data['action'] = $this->url->link('frmcreator/creator/update', 'token=' . $this->session->data['token'] . '&creator_id=' . $this->request->get['creator_id'], 'SSL');
        }

        $this->data['cancel'] = $this->url->link('frmcreator/creator', 'token=' . $this->session->data['token'], 'SSL');

        $this->data['token'] = $this->session->data['token'];

        if (isset($this->request->get['form_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
            $creator_info = $this->model_frmcreator_creator->getForm($this->request->get['form_id']);
        }


        if (isset($this->request->post['title'])) {
            $this->data['title'] = $this->request->post['title'];
        } elseif (!empty($creator_info)) {
            $this->data['title'] = $creator_info['title'];
        } else {
            $this->data['title'] = '';
        }

        if (isset($this->request->post['url'])) {
            $this->data['url'] = $this->request->post['url'];
        } elseif (!empty($creator_info)) {
            $this->data['url'] = $creator_info['url'];
        } else {
            $this->data['url'] = '';
        }

        if (isset($this->request->post['email'])) {
            $this->data['email'] = $this->request->post['email'];
        } elseif (!empty($creator_info)) {
            $this->data['email'] = $creator_info['email'];
        } else {
            $this->data['email'] = '';
        }

        if (isset($this->request->post['success_msg'])) {
            $this->data['success_msg'] = $this->request->post['success_msg'];
        } elseif (!empty($creator_info)) {
            $this->data['success_msg'] = $creator_info['success_msg'];
        } else {
            $this->data['success_msg'] = '';
        }


        if (isset($this->request->post['status'])) {
            $this->data['status'] = $this->request->post['status'];
        } elseif (!empty($creator_info)) {
            $this->data['status'] = $creator_info['status'];
        } else {
            $this->data['status'] = 1;
        }
        
        $this->data['html']  = isset($creator_info) ? $this->model_frmcreator_creator->getFormEdit(unserialize( $creator_info['formdata'])) : ''; 
        $this->template = 'frmcreator/creator_form.tpl';
        $this->children = array(
            'common/header',
            'common/footer'
        );

        $this->response->setOutput($this->render());
    }

    private function validateForm() {
        if (!$this->user->hasPermission('modify', 'frmcreator/creator')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }


        if ($this->error && !isset($this->error['warning'])) {
            $this->error['warning'] = $this->language->get('error_warning');
        }

        if (!$this->error) {
            return true;
        } else {
            return false;
        }
    }

    private function validateDelete() {
        if (!$this->user->hasPermission('modify', 'frmcreator/creator')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (!$this->error) {
            return true;
        } else {
            return false;
        }
    }

}

?>