<?php

class ControllerModuleCreator extends Controller {

    private $error = array();

    public function index($setting) {
        $this->language->load('information/creator');

        $this->load->model('catalog/creator');

        if (isset($this->request->get['form_id'])) {
            $form_id = $this->request->get['form_id'];
        } else {
            $form_id = 0;
        }

        if(isset($setting['form_id'])) $form_id =  $setting['form_id'];

        $form_info = $this->model_catalog_creator->getForm($form_id);

        $this->data['success_msg'] = $form_info['success_msg'];
        $form_email = $form_info['email'];
        $form_url = $form_info['url'];
        $this->data['heading_title'] = $form_info['title'];
        
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate() ) { 
            $file_upload = "";
            $content = "<table>";
            foreach ($_POST as $key => $row) {
                 if(strpos($key, "_1_")){ 
                      list($abc, $k )  = explode("_1_", $key); 
                      $file_upload = $abc == 'upload' ? $key : ''; 
                      if(in_array($abc, array('captcha','submit'))) 
                          continue; 
                      $key = $k ; 
                      
                 }
                $key = str_replace("_", " ", $key) ; 
                $content .= "<tr><td>{$key}</td><td>{$row}</td></tr>";
            }
            $content .= "</table>"; 
            if(isset($_FILES)){
               $tmp = array_keys($_FILES);
			   if(isset($tmp[0]) && $_FILES[$tmp[0]]['tmp_name'] != '')
               move_uploaded_file($_FILES[$tmp[0]]['tmp_name'], DIR_IMAGE. $_FILES[$tmp[0]]["name"]);
            } 
   
            $mail = new Mail();
            $mail->protocol = $this->config->get('config_mail_protocol');
            $mail->parameter = $this->config->get('config_mail_parameter');
            $mail->hostname = $this->config->get('config_smtp_host');
            $mail->username = $this->config->get('config_smtp_username');
            $mail->password = $this->config->get('config_smtp_password');
            $mail->port = $this->config->get('config_smtp_port');
            $mail->timeout = $this->config->get('config_smtp_timeout');

            $mail->setTo($form_info['email']);
            $mail->setFrom($form_email);
            $mail->setSender($form_url);
            $mail->setSubject(sprintf($heading_title));
            if(isset($tmp[0]) && $_FILES[$tmp[0]]["name"] != '') 
            $mail->addAttachment(DIR_IMAGE. $_FILES[$tmp[0]]["name"],$_FILES[$tmp[0]]["name"]); 
//            $mail->setText(strip_tags(html_entity_decode($content, ENT_QUOTES, 'UTF-8')));
            $mail->setHtml($content);
            $mail->send();
            $this->redirect($this->url->link('information/creator/success&id=' . $form_id));
        }

        
        $this->data['text_location'] = $this->language->get('text_location');
        $this->data['text_creator'] = $this->language->get('text_creator');
        $this->data['text_address'] = $this->language->get('text_address');
        $this->data['text_telephone'] = $this->language->get('text_telephone');
        $this->data['text_fax'] = $this->language->get('text_fax');

        $this->data['entry_name'] = $this->language->get('entry_name');
        $this->data['entry_email'] = $this->language->get('entry_email');
        $this->data['entry_enquiry'] = $this->language->get('entry_enquiry');
        $this->data['entry_captcha'] = $this->language->get('entry_captcha');

      

        if (isset($this->session->data['error_captcha'])) {
            $this->data['error_captcha'] = $this->session->data['error_captcha'];
        } else {
            $this->data['error_captcha'] = '';
        }
        
        if (isset($this->session->data['email'])) {
            $this->data['email'] = $this->session->data['email'];
        } else {
            $this->data['email'] = '';
        }

		unset($this->session->data['error_captcha']);
		unset($this->session->data['email']);


        $this->data['button_continue'] = $this->language->get('button_continue');

        $this->data['action'] = $this->url->link('information/creator', '&form_id=' . $form_id.'&redirect='.base64_encode($_SERVER['REQUEST_URI']), 'SSL');
     
        $this->data['formdata'] = $this->model_catalog_creator->getFormShow(unserialize($form_info['formdata']));

        if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/module/creator.tpl')) {
            $this->template = $this->config->get('config_template') . '/template/module/creator.tpl';
        } else {
            $this->template = 'default/template/module/creator.tpl';
        }
        
        $this->render();
    }


    public function captcha() {
        $this->load->library('captcha');

        $captcha = new Captcha();

        $this->session->data['captcha'] = $captcha->getCode();

        $captcha->showImage();
    }

    private function validate() {

        foreach ($this->request->post as $key => $val) {
            if (strpos($key, "_1_")) {
                list($type,$name) = explode("_1_", $key);
              
                if( $type == 'captcha')
                if (!isset($this->session->data['captcha']) || ($this->session->data['captcha'] != $this->request->post[$key])) {
                    $this->error['error_captcha'] = $this->language->get('error_captcha');
                }
            }
        }
        if (!$this->error) {
            return true;
        } else {
            return false;
        }
    }

}

?>
