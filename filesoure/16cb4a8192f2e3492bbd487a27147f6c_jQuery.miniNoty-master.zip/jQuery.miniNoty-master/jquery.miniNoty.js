/**
 * jQuery.miniNoty - Супер простой/маленький в использовании уведомитель
 * Сайт плагина - https://github.com/StepanMas/jQuery.miniNoty
 */

;(function($){

	$.miniNoty = function(message, type){

		// settings
		var timeToHide = 3000,  // время до скрытия
			timeAnimEnd = 500, // время анимаций в SCSS
			padding = 10 // css padding-bottom заданный .miniNoty в SCSS

		var cls = 'miniNoty miniNoty-' + (type ? type : 'success'),
			node = $('<div/>', {
				'class': cls,
				html: message
			})

		// Если уже есть уведомления
		if($('.miniNoty').length){

			var elLast = $('.miniNoty:last-child'),
				elLastBottom = parseInt(elLast.css('bottom')),
				elLastHeight = elLast.outerHeight()

			node.css('bottom', elLastBottom + elLastHeight + padding + 'px')
		}

		$('body').append(node)

		// delete on click
		node.click(function(){
			node.removeClass('miniNoty-show')
			setTimeout(function () {

				node.remove()

			}, timeAnimEnd)
		})

		// push stack
		setTimeout(function(){
			node.addClass('miniNoty-show')
		}, 100)

		// timeout to hide
		setTimeout(function(){

			node.removeClass('miniNoty-show')
			setTimeout(function () {

				node.remove()

			}, timeAnimEnd)

		}, timeToHide)
	}

})(jQuery);